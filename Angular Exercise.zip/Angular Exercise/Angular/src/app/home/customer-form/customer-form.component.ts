import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CustomerServiceService } from 'src/app/customer-service.service';

@Component({
  selector: 'app-customer-form',
  templateUrl: './customer-form.component.html',
  styleUrls: ['./customer-form.component.css']
})
export class CustomerFormComponent implements OnInit {

  customerForm = this.formBuilder.group({
    fname: ['',[Validators.required,Validators.pattern('[A-Za-z]')]],
    lname: ['',[Validators.required,Validators.pattern('[A-Z]')]],
    DOB:['',[Validators.required]],
    Gender:['',[Validators.required,Validators.pattern('[A-Z]')]],
    ContactNo:['',[Validators.required]],
    EmailId:['',[Validators.required,Validators.email]],
    Address_1:['',[Validators.required]],
    Address_2:['',[Validators.required]],
    City:['',[Validators.required]],
    State:['',[Validators.required]],
    Zip:['',[Validators.required]],

  });
  constructor(private formBuilder: FormBuilder,private customerService$:CustomerServiceService) { }

  ngOnInit(): void {


  }
  fieldValidation(fieldName:string)
  {
    return this.customerForm.get(fieldName)?.dirty&&this.customerForm.get(fieldName)?.errors?true:false;

  }
  submitForm(){
    this.customerService$.sendCustomerValue(this.customerForm.value).subscribe((response=>{
      alert("Customer Submited Successfully")
    }),
    (error)=>{
      alert("Error Saving Customer")

    }
    
    )
  }

}
