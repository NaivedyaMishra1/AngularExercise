import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {

  constructor(private http:HttpClient) { }
  sendCustomerValue(value:any){
   return  this.http.post("localhost:3000/sendCustomer",value)
  }
}
